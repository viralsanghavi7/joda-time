#define REDIS_GIT_SHA1 "8a5b48ae"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "viral-IdeaPad-U430-Touch-1445533343"
